package program;

import merkeziIslemBirimi.IMerkeziIslemBirimi;
import merkeziIslemBirimi.MerkeziIslemBirimi;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IMerkeziIslemBirimi merkeziIslemBirimi = new MerkeziIslemBirimi();
		merkeziIslemBirimi.arayuzIslemSecimi();
		
	}

}
