package cevreBirimleri;

public class Eyleyici implements IEyleyici{

	String durum = "kapali";
	@Override
	public String sogutucuDurum() {
		// TODO Auto-generated method stub
		return durum;
		
	}

	@Override
	public void sogutucuAc() {
		// TODO Auto-generated method stub
		if(durum == "acik") {
			System.out.println("Cihaz zaten a��k.");
		}
		else {
			durum = "acik";
			System.out.println("Cihaz a��ld�.");
		}		
	}

	@Override
	public void sogutucuKapat() {
		// TODO Auto-generated method stub
		if(durum == "kapali") {
			System.out.println("Cihaz zaten kapal�.");
		}
		else {
			durum = "kapali";
			System.out.println("Cihaz kapat�ld�.");
		}		
	}
}
