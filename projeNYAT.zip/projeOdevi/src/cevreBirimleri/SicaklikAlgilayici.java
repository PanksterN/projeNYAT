package cevreBirimleri;
import java.util.Random;
public class SicaklikAlgilayici implements ISicaklikAlgilayici{

	@Override
	public int sicaklikDerecesi() {
		// TODO Auto-generated method stub
		Random r = new Random();
		int returnSayisi = r.nextInt(20);
		return returnSayisi;
	}

}
