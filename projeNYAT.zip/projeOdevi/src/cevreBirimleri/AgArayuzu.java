package cevreBirimleri;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import veritabani.postgreSQL.IPostgreDb;
import veritabani.postgreSQL.PostgreDb;

public class AgArayuzu implements IAgArayuzu{

	
	Scanner girdi = new Scanner(System.in);
	
	@Override
	public void arayuzGiris() {
		// TODO Auto-generated method stub
		IPostgreDb postgreDb= new PostgreDb();
		postgreDb.baglan();
		String kullaniciGirdisi;
		String sifreGirdisi;
		boolean kullaniciGirdiBool = false;
		
		String sql;
		
		while(true) {
			System.out.print("Kullan�c� Ad�: ");
			kullaniciGirdisi = girdi.nextLine();
		
			System.out.print("�ifre: ");
			sifreGirdisi = girdi.nextLine();
		
			sql = "select * from adminler";
			ResultSet rs = postgreDb.listele(sql);
			try {
				while(rs.next()) {
					
					if(kullaniciGirdisi.equals(rs.getString("kullaniciAdi")) && sifreGirdisi.equals(rs.getString("sifre"))) {
						kullaniciGirdiBool = true;
						break;
					}				
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			if(kullaniciGirdiBool == true) {
				System.out.println("Giri� ba�ar�l�.");
				break;
			}
			else {
				System.out.println("Giri� ba�ar�s�z. Tekrar deneyin.");
			}
			}
		}

	@Override
	public String arayuzIslem() {
		// TODO Auto-generated method stub
		
		String secilenIslem;
		
		System.out.println("��lem Se�iniz:");
		System.out.println("1. So�utucuyu A�");
		System.out.println("2. So�utucuyu Kapat");
		System.out.println("3. So�utucu Derecesi G�ster");
		System.out.println("4. ��k��");
		
		secilenIslem = girdi.nextLine();
		
		return secilenIslem;
		
		
	}
	
}
