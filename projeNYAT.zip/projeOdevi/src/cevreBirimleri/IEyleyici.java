package cevreBirimleri;

public interface IEyleyici {

	public String sogutucuDurum();
	public void sogutucuAc();
	public void sogutucuKapat();
	
	
}
