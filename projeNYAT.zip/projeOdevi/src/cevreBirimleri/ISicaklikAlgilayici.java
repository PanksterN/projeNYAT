package cevreBirimleri;

public interface ISicaklikAlgilayici {
	public int sicaklikDerecesi();
}
