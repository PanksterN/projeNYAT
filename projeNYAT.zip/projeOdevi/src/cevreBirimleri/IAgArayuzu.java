package cevreBirimleri;

public interface IAgArayuzu {
	public void arayuzGiris();
	public String arayuzIslem();
}
