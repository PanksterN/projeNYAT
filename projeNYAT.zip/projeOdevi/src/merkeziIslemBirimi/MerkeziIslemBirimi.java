package merkeziIslemBirimi;

import cevreBirimleri.AgArayuzu;
import cevreBirimleri.Eyleyici;
import cevreBirimleri.IAgArayuzu;
import cevreBirimleri.IEyleyici;
import cevreBirimleri.ISicaklikAlgilayici;
import cevreBirimleri.SicaklikAlgilayici;

public class MerkeziIslemBirimi implements IMerkeziIslemBirimi{

	String secilenIslem;
	IAgArayuzu arayuz = new AgArayuzu();
	IEyleyici eyleyici = new Eyleyici();
	ISicaklikAlgilayici sicaklikAlgilayici = new SicaklikAlgilayici();
	@Override
	public void arayuzIslemSecimi() {
		// TODO Auto-generated method stub
		arayuzGiris();
		while(true) {
			secilenIslem = arayuz.arayuzIslem();
			if(secilenIslem.equals("1")) {sogutucuAc();}
			else if(secilenIslem.equals("2")) {sogutucuKapat();}
			else if(secilenIslem.equals("3")) {if(sogutucuAcikMi()) {
				System.out.print("So�utucu Derecesi:");
				System.out.println(sogutucuDerecesi());				
			}
			else System.out.println("Cihaz kapal�!");			
			}
			else if(secilenIslem.equals("4")) { System.out.println("��k�� yap�ld�."); break;}
			else { System.out.println("Ge�ersiz i�lem se�tiniz. Tekrar deneyin.");}
		}
	}
	@Override
	public void arayuzGiris() {
		// TODO Auto-generated method stub
		arayuz.arayuzGiris();
	}
	@Override
	public void sogutucuAc() {
		// TODO Auto-generated method stub
		eyleyici.sogutucuAc();
	}
	@Override
	public void sogutucuKapat() {
		// TODO Auto-generated method stub
		eyleyici.sogutucuKapat();
		
	}
	@Override
	public boolean sogutucuAcikMi() {
		// TODO Auto-generated method stub
		if(eyleyici.sogutucuDurum().equals("acik")) {
			return true;			
		}
		else return false;
	}
	@Override
	public int sogutucuDerecesi() {
		// TODO Auto-generated method stub
		return sicaklikAlgilayici.sicaklikDerecesi();
	}

}
