package merkeziIslemBirimi;

public interface IMerkeziIslemBirimi {
	public void arayuzGiris();
	public void arayuzIslemSecimi();
	public void sogutucuAc();
	public void sogutucuKapat();
	public boolean sogutucuAcikMi();
	public int sogutucuDerecesi();
}


