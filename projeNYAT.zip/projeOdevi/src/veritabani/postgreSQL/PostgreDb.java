package veritabani.postgreSQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PostgreDb implements IPostgreDb{

	String url = "jdbc:postgresql://localhost:5432/projeOdevi";
	Connection conn = null;
	
	@Override
	public void baglan() {
		try {
			conn = DriverManager.getConnection(url,"postgres","admin");
			//ba�lant� ba�ar�l�
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ResultSet listele(String sql) {
		
		try {			
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			return rs;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
		
}
