package veritabani.postgreSQL;

import java.sql.ResultSet;

public interface IPostgreDb {
	public void baglan();
	public ResultSet listele(String sql);
}
